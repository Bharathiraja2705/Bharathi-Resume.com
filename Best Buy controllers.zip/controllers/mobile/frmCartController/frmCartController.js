var totalPrice=0.0;
var finaldata = [];
//cartItemLength=0;
var Tamount=0.0;
define({



  //Type your controller code here
  onNavigate:function(){
    //this.cartLength();
   // finaldata =[];
    kony.model.ApplicationContext.showLoadingScreen("Loading...");
   this.view.flxMenu.setVisibility(false);
    this.cartLength();
    var responseData=[
      {
        "menu":"Home",
        "logo":"appmenuhome.png"
      },
      {
        "menu":"Stores",
        "logo":"appmenustore.png"
      },
      {
        "menu":"Cart",
        "logo":"appmenucart.png"
      }
    ];
    this.view.segMenuItem.widgetDataMap={
      "lblMenu":"menu",
      "imgLogo":"logo"
   };
    this.view.Head.imgBack.setVisibility(false);
   this.view.segMenuItem.setData(responseData);
    //this.cartLength();
   this.view.Head.imgMenu.onTouchEnd=this.onVisibleMenu;
    //this.view.segCartItems.removeAll();
  },
  onMenu:function(rowNumber)
  { 
    if(rowNumber===0)
    {
      // this.setAnimationMenuClose;
      var nav = new kony.mvc.Navigation("frmHome");
      nav.navigate();
    }
    else if(rowNumber===1)
    {
      //       this.setAnimationMenuClose;
      //       alert("Comming Soon");
      var navi = new kony.mvc.Navigation("frmLocation");
      navi.navigate();
    }
    else if(rowNumber===2)
    {
      // this.setAnimationMenuClose;
      var navig = new kony.mvc.Navigation("frmCart");
      navig.navigate();
    }
  },
  onVisibleMenu:function()
  {
    if(this.view.flxMenu.isVisible===true)
    {
      this.setAnimationMenuClose();
    }
    else
    {
      this.setAnimationMenu();
    }
  },
  setAnimationMenu : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "1%"
      },
      "100": {
        "top": "2dp",
        "left": "0%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.

    this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
  },
  setAnimationMenuClose : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "0%"
      },
      "100": {
        "top": "2dp",
        "left": "1%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.3,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
    //this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
    this.view.flxMenu.setVisibility(false);
    this.view.flxMain.forceLayout();
  },
  cartLength:function(){
    // var length=cartArray.length();
    // var cartArray=[];
    //cartItemsLength=cartArray.length;
    if(cartItemLength!==0){
      this.view.segCart.setVisibility(true);
      this.view.lblAmount.setVisibility(true);
      this.view.lblNoItems.setVisibility(false);
      for(var iter=0;iter<cartArray.length;iter++){
        if(iter!==cartArray.length){
          this.invokeService(cartArray[iter]);
         // alert(cartArray[iter]);
        }
      }
    }
    else{
      this.view.lblNoItems.setVisibility(true);
      this.view.segCart.setVisibility(false);
      this.view.lblAmount.setVisibility(false);
      this.view.lblNoItems.setVisibility(true);
      this.view.lblNoItems.text="Shopping Cart is empty.Please browse Products and them to your Cart.";
  kony.model.ApplicationContext.dismissLoadingScreen();


    }
  },
  invokeService:function(cartItem){
    var scope=this;
    var integrationSvc=kony.sdk.getCurrentInstance().getIntegrationService("BestBuy");
    var data={
      "Product_ID":cartItem[0]
    };



    var headers={};
    integrationSvc.invokeOperation("getProducts", headers,data, operationSuccess, operationFailure);

    function operationSuccess(res){


      productDatas = res.products;
      for (var item in productDatas) {
        if(productDatas[item]["sku"]===cartItem[1]){
          finaldata.push({
            "imgName": {
              "text": productDatas[item]["name"],

            },
            "imgAmount": {
              "text": "$ "+productDatas[item]["regularPrice"],
            },
            "imgDeleteCart":{
              "src":"cartremoveitem.png"
            }

          });
          //selectedProductPrice=this.view.segCart.selectedRowItems[0].salePrice;
          totalPrice=totalPrice+parseFloat(productDatas[item]["regularPrice"]);
        }

      }
      scope.view.lblAmount.text="Total"+totalPrice;
      scope.view.segCart.setData(finaldata);
      cartArray.pop();
        kony.model.ApplicationContext.dismissLoadingScreen();
    }

    function operationFailure(res){
      alert("Failure");
    }
  },
  setAnimation : function(rowNumber, animationType){
    var transformObject1 = kony.ui.makeAffineTransform();
    var transformObject2 = kony.ui.makeAffineTransform();
    if(animationType==="translate"){
      transformObject1.translate(200, 0);
      transformObject2.translate(0, 0);
    }
    else if(animationType==="scale"){
      transformObject1.scale(1,1);
      transformObject2.scale(0,0);
    }
    else if(animationType==="rotate"){
      transformObject1.rotate(90);
      transformObject2.rotate(0);
    }
    var animationObject = kony.ui.createAnimation(
      {"0":{"transform":transformObject1,"stepConfig":{"timingFunction":kony.anim.LINEAR}},
       "100":{"transform":transformObject2,"stepConfig":{"timingFunction":kony.anim.LINEAR}}});
    var animationConfig = {
      duration: 1,
      fillMode: kony.anim.FILL_MODE_FORWARDS
    };
    var animationCallbacks = {"animationEnd":function(){kony.print("animation END");}};
    var animationDefObject={definition:animationObject,config:animationConfig,callbacks:animationCallbacks};
    // this.view.segCars.setAnimations({visible:animationDefObject});
  // this.view.lblAmount.animate(animationDefObject);
   // this.view.lblAmount.animate(animationObject, animationConfig, animationCallbacks)
    this.view.segCart.removeAt(rowNumber, 0,animationDefObject);
   //Tamount= this.view.segCart.selectedRowItems[0].regularPrice;
    //alert(Tamount);
    
  },
  onRowClick: function(rowNumber){
    //this.view.seg
    var data;
    data=this.view.segCart.selectedRowItems[0].imgAmount.text;
    //alert(data);
    var amountArray;
    amountArray=data.split(" ");
    alert(amountArray[1]);
    alert(totalPrice);
    this.view.lblAmount.text="Total"+(totalPrice-parseFloat(amountArray[1]));
    //alert(data[1]);
    this.setAnimation(rowNumber, "scale");
    
  }
});