define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onNavigate defined for frmCart **/
    onNavigate: function AS_Form_de637ae1fca34e15a3ed03c7e44dc4f3(eventobject) {
        var self = this;
        return self.cartLength.call(this);
    },
    /** onTouchEnd defined for imgBack **/
    AS_Image_b6b89c9480984067abc897557315458e: function AS_Image_b6b89c9480984067abc897557315458e(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    },
    /** onRowClick defined for segMenuItem **/
    AS_Segment_a0d55a5ed8f641f584e83e3c6f6e2e7d: function AS_Segment_a0d55a5ed8f641f584e83e3c6f6e2e7d(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.onMenu.call(this, rowNumber);
    },
    /** onRowClick defined for segCart **/
    AS_Segment_cff6b67c056b46de980dd31d737e2773: function AS_Segment_cff6b67c056b46de980dd31d737e2773(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.onRowClick.call(this, rowNumber);
    }
});