var categoryID = "cat00000";
var path="Home";
var result;
var root=[];
root.push("Home");
var catId=[];
var navSecond;
catId.push(categoryID);
//var categoryID="$Category_ID";
define({

  onNavigate: function()
  {  
    categoryID = "cat00000";
    path="Home";
    //root.pop();
    root=[];
   root.push("Home");
    this.view.lblPath.text=root[0];
    //this.view.segProductList.removeAll();
    this.view.flxHome.forceLayout();
 // kony.model.ApplicationContext.showLoadingScreen("Loading...");
    this.fetchCategoryyByID();
    //frmHome.forceLayout();
    //kony.model.ApplicationContext.showLoadingScreen("Loading...");
    this.view.flxMenu.setVisibility(false);
    //this.fetchCategoryyByID();
    var responseData=[
      {
        "menu":"Home",
        "logo":"appmenuhome.png"
      },
      {
        "menu":"Stores",
        "logo":"appmenustore.png"
      },
      {
        "menu":"Cart",
        "logo":"appmenucart.png"
      }
    ];
    this.view.segMenuItem.widgetDataMap={
      "lblMenu":"menu",
      "imgLogo":"logo"
    };
    this.view.Head.imgBack.setVisibility(false);
    this.view.segMenuItem.setData(responseData);
    this.view.Head.imgSerch.onTouchEnd=this.setAnimation;

    this.view.btnClose.onClick=this.setAnimationSearch;
    //this.view.Head.imgMenu.onTouchEnd=this.setVisisbleMenu;
   this.view.Head.imgMenu.onTouchEnd=this.onVisibleMenu;
  //  this.view.ArrowLeft.onTouchEnd=this.setAnimationMenuClose;
    this.view.segProductList.onRowClick=this.fetchsubCategories;
    //this.view.Head.imgBack.onTouchEnd=this.goHome;
    //this.view.segMenuItem.onRowClick=this.onMenu(rowNumber);
    this.view.Head.imgBack.onTouchEnd=this.setPath;
    //this.view.segMenuItem.onRowClick=this.onMenu(rowNumber);
  },
  onVisibleMenu:function()
  {
     if(this.view.flxMenu.isVisible===true)
      {
        this.setAnimationMenuClose();
      }
    else
      {
        this.setAnimationMenu();
      }
  },
  setVisisbleMenu:function()
  {
    if(this.view.flxMenu.isVisible===true)
      {
        this.view.flxMain.setVisibility(false);
      }
    else
      {
        this.view.flxMain.setVisibility(true);
      }
  },
  goHome:function()
  {   
    frmHome.forceLayout();
    path="Home";
    this.view.lblPath.text="Home";
    //     this.view.segProductList.removeAll();
    //     this.fetchCategoryyByID();

    //     this.onNavigate();
    // path="Home";
    //this.view.segProductList.removeAll();
    //     var nav=new kony.mvc.Navigation("frmHome");
    //     nav.navigate();
  },
  onMenu:function(rowNumber)
  { 
    if(rowNumber===0)
    {
      // this.setAnimationMenuClose;
      var nav = new kony.mvc.Navigation("frmHome");
      nav.navigate();
    }
    else if(rowNumber===1)
    {
//       this.setAnimationMenuClose;
//       alert("Comming Soon");
      var navi = new kony.mvc.Navigation("frmLocation");
      navi.navigate();
    }
    else if(rowNumber===2)
    {
      // this.setAnimationMenuClose;
      var navig = new kony.mvc.Navigation("frmCart");
      navig.navigate();
    }
  },
  setAnimation : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "100%"
      },
      "100": {
        "top": "2dp",
        "left": "1%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxSearch.setVisibility(true);
    this.view.flxSearch.animate(animationDefObject, animationConfig);
  },
  setAnimationSearch : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "1%"
      },
      "100": {
        "top": "2dp",
        "left": "100%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS,
    
      
    "animationEnd": animationCallbackFn
    

    };
    // Creates an object that defines an animation.
    var animationCallbackFn = {
      "animationEnd":function()
      {
        //kony.print("animation END");
        alert("Welcome");
      }
    };
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxSearch.animate(animationDefObject, animationConfig);
    this.view.flxSearch.setVisibility(false);
//     function callback(){



//     }
  },



  flxClose:function()
  {
    this.view.flxSearch.setVisibility(false);
  },
  setAnimationMenu : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "1%",
        //"right" : "100%"
      },
      "100": {
        "top": "2dp",
      "left": "0%",
       // "right":"50%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
    if(this.view.flxMenu.isVisible===true)
      {
        this.view.flxMenu.setVisibility(false);
      }
    else
      {
        this.view.flxMenu.setVisibility(true);
      }
    //this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
  },
  setAnimationMenuClose : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "0%"
      },
      "100": {
        "top": "2dp",
        "left": "1%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
    // this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
    this.view.flxMenu.setVisibility(false);
    this.view.flxMain.forceLayout();
  },
  hideMenuFlx:function()
  {
    // this.view.flxMenu.setVisibility(false);
    this.view.flxMenu.forceLayout();
  },
  fetchCategoryyByID : function(){
    var serviceName = "BestBuy";
    var integrationService = KNYMobileFabric.getIntegrationService(serviceName);
    var operationName = "getCategory";
    var params = {
      "Category_ID":categoryID
    };
    var headers={};
    integrationService.invokeOperation(operationName, headers, params, this.operationSuccess, this.operationFailure);
    this.view.segProductList.onClick=this.reFreshWithRowAnim();
  },
  navigateProduct:function(parms)
  { 
    navSecond=parms;
   // alert("Hello");
    //alert(parms);
    var nav= new kony.mvc.Navigation("frmProductDetails");
    nav.navigate(parms);
  },
  operationSuccess: function(res){
    // alert("Success"+res);
    var data =[];
    data = res;
    if((res.subCategories.length>3&&res.subCategories!==undefined&&res.subCategories!==""))
    {


      this.view.segProductList.widgetDataMap=this.getWidgetData(data);
      this.view.segProductList.setData(data.subCategories);
      this.view.segProductList.onClick=this.reFreshWithRowAnim();
      kony.model.ApplicationContext.dismissLoadingScreen();
    }
    else if((res.subCategories.length<=3)){
      this.navigateProduct({"CatagoryById":selectedRowID});
      //alert(selectedRowID);
    }
    else{
      alert("sdfgfd");
    }
  },
  operationFailure:function(res){
    // alert("failure");
  },



  getWidgetData:function(){
    var response={
      "lblProductName":"name"

    };
    return response;
  },



  reFreshWithRowAnim:function()
  {
    //var data;
    var data = this.view.segProductList.data;
    var addRowAnim=this.getAddRowAnim();
    this.view.segProductList.setAnimations(addRowAnim);
    //this.view.segProductList.addAll(data,addRowAnim);
    this.onRowDisplayFunction();
  },



  getAddRowAnim:function()
  {



    var transformProp1 = kony.ui.makeAffineTransform();
    transformProp1.scale(10,5);
    var transformProp3 = kony.ui.makeAffineTransform();
    transformProp3.scale(12,7);
    var animDefinitionOne =
        {
          50:
          {



            "anchorPoint":{"x":-50,"y":0},
            "transform":transformProp1
          },
          100:
          {



            "anchorPoint":{"x":-15,"y":35},
            "transform":transformProp3
          }
        };
    var animObj = kony.ui.createAnimation(animDefinitionOne);
    var animConf =
        {
          delay:0,
          fillMode:kony.anim.EFFECT_LEFT,
          duration:1
        };
    var addRowAnimtion =
        {
          definition: animObj,
          config: animConf,
          callbacks: null
        };
    return addRowAnimtion;
  },
  onRowDisplayFunction:function ()
  {



    var animConfig =
        {
          "backgroundColour":"#00FFFF",
          "duration":0.9,
          "iterationCount":1,
          "delay":0,
          "fillMode":kony.anim.LEFT
        };
    //scale
    var transformProp1 = kony.ui.makeAffineTransform();
    transformProp1.scale(20,0);
    var transformProp3 = kony.ui.makeAffineTransform();
    transformProp3.scale(1,1);
    var animDefinitionOne =
        {
          50:
          {
            "backgroundColour":"#00FFFF",
            "anchorPoint":{"x":-20,"y":0},
            "transform":transformProp1
          },
          100:
          {
            "backgroundColour":"#00FFFF",
            "anchorPoint":{"x":-45,"y":55},
            "transform":transformProp3
          }
        };
    animDefinition = kony.ui.createAnimation(animDefinitionOne);
    var finalAnimation =
        {
          definition: animDefinition,
          config: animConfig
        };
    this.view.segProductList.setAnimations({visible: finalAnimation});
  },
  fetchsubCategories:function(){
    // var path="Home";
    //root.push("Home");
    this.view.Head.imgBack.setVisibility(true);
    selectedRowID=this.view.segProductList.selectedRowItems[0].id;
    selectedRow=this.view.segProductList.selectedRowItems[0].name;
    categoryID=selectedRowID;
    result=selectedRow;
    this.fetchCategoryyByID();
    // var path="Home";
    //root.push(selectedRow);
    path=path+"->"+selectedRow;
    catId.push(selectedRowID);
    root.push(path);
    //this.view.lblPath.text=root[0]+root[1]+root[2]+root[3]+root[4];
    //   for(var i=0;i<root.length;i++)
    //     { 
    //       //path=path+"->"+root[i];
    //       root.push(root[i]);
    //       //this.view.lblPath.text=root[i];
    //     }
    var l=root.length-1;
    this.view.lblPath.text=root[l];
  },
  setPath:function()
  {
    if(root.length>1)
    {
      root.pop();
      var l=root.length-1;
      this.view.lblPath.text=root[l];
      catId.pop();
      var catLength=catId.length;
      categoryID=catId[catLength];
    this.fetchCategoryyByID();
      
    }
    else
    {
      this.view.Head.imgBack.setVisibility(false);
    }
  },
//   productDetails: function(){
// productId=this.view.segProduct.selectedRowItems[0].sku;
// productName=this.view.segProduct.selectedRowItems[0].name;
// productPrice=this.view.segProduct.selectedRowItems[0].salePrice;
// productRating=this.view.segProductList.selectedRowItems[0].customerReviewAverage;
// productImage=this.view.segProduct.selectedRowItems[0].image;

// this.navigateToProductDetails();
// var row_items=this.view.segProduct.selectedRowItems;
// alert("The selected row items are "+JSON.stringify(row_items));
// // productID=selectedRowID;
// // this.fetchProductByID();
// },
// navigateToProductDetails: function(){
// var productDetails=[productId,productName,productPrice,productRating,productImage];
// var navigateProductDetails=new kony.mvc.Navigation("frmProduct");
// navigateProductDetails.navigate(productDetails);
// }
});