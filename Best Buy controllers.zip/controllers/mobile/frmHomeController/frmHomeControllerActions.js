define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnClose **/
    AS_Button_aee97f81e4ff4731b1e39ff845431138: function AS_Button_aee97f81e4ff4731b1e39ff845431138(eventobject) {
        var self = this;
        this.setAnimationSearch();
        //this.view.flxSearch.setVisibility(false);
    },
    /** init defined for frmHome **/
    AS_Form_h5a53074ad8840ad973957cd7d9b9ddc: function AS_Form_h5a53074ad8840ad973957cd7d9b9ddc(eventobject) {
        var self = this;
        kony.model.ApplicationContext.showLoadingScreen("Loading...");
    },
    /** onTouchEnd defined for imgLogo **/
    AS_Image_i4148f3cf4b84deab200d1f8882d8604: function AS_Image_i4148f3cf4b84deab200d1f8882d8604(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProductDetails");
        ntf.navigate();
    },
    /** onRowClick defined for segProductList **/
    AS_Segment_bbbb47ff4c2f47c98981b3368dbf9ef2: function AS_Segment_bbbb47ff4c2f47c98981b3368dbf9ef2(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.fetchsubCategories.call(this);
    },
    /** onRowClick defined for segMenuItem **/
    AS_Segment_d5044d615d704e00acee7e4b63b4a0fd: function AS_Segment_d5044d615d704e00acee7e4b63b4a0fd(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.onMenu.call(this, rowNumber);
    }
});