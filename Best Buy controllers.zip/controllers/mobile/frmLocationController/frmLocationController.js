var cityName;
define({
  /*Initialize the screen*/
  onNavigate:function()
  {
    this.view.MapStores.onPinClick=this.display;
    this.view.flxStoreDetails.setVisibility(false);
    this.view.flxMenu.setVisibility(false);
    var responseData=[
      {
        "menu":"Home",
        "logo":"appmenuhome.png"
      },
      {
        "menu":"Stores",
        "logo":"appmenustore.png"
      },
      {
        "menu":"Cart",
        "logo":"appmenucart.png"
      }
    ];
    this.view.segMenuItem.widgetDataMap={
      "lblMenu":"menu",
      "imgLogo":"logo"
    };
    //this.view.Head.imgBack.setVisibility(false);
    this.view.segMenuItem.setData(responseData);
    this.view.btnSearch.onClick=this.getStoresDetails;
    this.view.Head.imgMenu.onTouchEnd=this.onVisibleMenu;
  },
  onMenu:function(rowNumber)
  { 
    if(rowNumber===0)
    {
      // this.setAnimationMenuClose;
      var nav = new kony.mvc.Navigation("frmHome");
      nav.navigate();
    }
    else if(rowNumber===1)
    {
      //       this.setAnimationMenuClose;
      //       alert("Comming Soon");
      var navi = new kony.mvc.Navigation("frmLocation");
      navi.navigate();
    }
    else if(rowNumber===2)
    {
      // this.setAnimationMenuClose;
      var navig = new kony.mvc.Navigation("frmCart");
      navig.navigate();
    }
  },
  onVisibleMenu:function()
  {
    if(this.view.flxMenu.isVisible===true)
    {
      this.setAnimationMenuClose();
    }
    else
    {
      this.setAnimationMenu();
    }
  },
  setAnimationMenu : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "1%"
      },
      "100": {
        "top": "2dp",
        "left": "0%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.

    this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
  },
  setAnimationMenuClose : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "0%"
      },
      "100": {
        "top": "2dp",
        "left": "1%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
    // this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
    this.view.flxMenu.setVisibility(false);
    this.view.flxMain.forceLayout();
  },
  // initFunction:function(){
  // //this.view.txtMapSearchField.text="";
  // //this.view.MapStores.clear();
  // },
  /*Function to get the Stores details based on the Search text*/
  getStoresDetails:function(){
    cityName=this.view.txtMapSearchField.text;
    if(this.view.txtMapSearchField.text !== ""){
      this.view.MapStores.clear();
      this.view.MapStores.enableMultipleCallouts = true;
      kony.model.ApplicationContext.showLoadingScreen("Loading");
      var data = {"locationId":this.view.txtMapSearchField.text};
      var serviceName = "BestBuy";
      var integrationService = KNYMobileFabric.getIntegrationService(serviceName);
      var operationName = "GetStoresLocation";
      var headers={};
      integrationService.invokeOperation(operationName, headers, data, this.getStoresLocationOperationSuccess, this.serviceOperationFailure);
    }else{
      alert("Please enter a city in search box");
    }
  },
  /*Function to map the Stores*/
  getStoresLocationOperationSuccess:function(res){
    alert("Success");
   // var len=[];
    var len=res.stores;
//     var leng=len.length;
//     alert(leng);
    //   var leng=len.length;
    //   alert(leng);
    // if(res.stores.length>0){
    //for(var i=0;i<res.stores.length;i++){
    for(var item in len)
    {
//       if(len[store]["city"]===cityName)
//       {
      
        var pinLocations={
          id:len[item]["storeId"],
          lat:len[item]["lat"],
         // lan:len[store]["storeId"],
          lon:len[item]["lng"],
//           lat:res.store.lat,
//           lon:res.stores.lng,
          showCallout:false,
          calloutData:{
            
        lblName:len[item]["longName"],
            lblAddress :len[item]["address"]+" ,#"+len[item]["fullPostalCode"],
      //  lblAddressValue :res.stores[i].address+" ,#"+res.stores[i].fullPostalCode,
        lblPhone: len[item]["phone"]
        }
        };
      this.view.lblName.text=len[item]["longName"];
      this.view.lblPhone.text=len[item]["phone"];
      this.view.lblAddress.text=len[item]["address"]+" ,#"+len[item]["fullPostalCode"];
        this.view.MapStores.addPin(pinLocations);    
    }
//     for(var i=1;i<5;i++){
//       var pinLocations={
//         //   id:res.store[i].storeId,
//         // lat:res.store[i].lat,
//         // lon:res.stores[i].lng,
//         id:res.store.storeId,
//         lat:res.store.lat,
//         lon:res.stores.lng,
//         showCallout:false,
//         // calloutData:{
//         // lblName:res.stores[i].longName,
//         // lblAddressValue :res.stores[i].address+" ,#"+res.stores[i].fullPostalCode,
//         // lblPhoneValue: res.stores[i].phone
//         // }
//       };
//       this.view.MapStores.addPin(pinLocations);
    
    // }else{
    // alert("No stores found for this city search");
    // }
    kony.model.ApplicationContext.dismissLoadingScreen();
  },
  display:function()
  {
    if(this.view.flxStoreDetails.isVisibility==="true")
      {
        this.view.flxStoreDetails.setVisibility(false);
      }
    else
      {
        this.setAnimationReviewUp();
       // this.view.flxStoreDetails.setVisibility(true);
      }
  },
  serviceOperationFailure:function(res)
  {
    alert("failure");
    kony.model.ApplicationContext.dismissLoadingScreen();
  },
  /*Function to show the Pin details*/
  setAnimationReviewUp : function(){
    //alert("Up Animation ");
    var transformObject1 = kony.ui.makeAffineTransform();
    //var transformObject2 = kony.ui.makeAffineTransform();
    //transformObject1.translate(10, 0);
    //transformObject2.translate(0, 0);


    transformObject1.scale(0.1,1);
    //transformObject2.scale(0,0);
    var animationDef = {
      "0": {
        "top": "100%",
        "left": "0%"
      },
      "100": {
        "top": "58%",
        "left": "0%"
      }
      // "100": {
      // "transform": transformObject1
      // }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
//     this.view.flxMenu.setVisibility(true);
//       this.view.flxReview.setVisibility(true);
//      this.view.imgDown.setVisibility(true);
//       this.view.imgUp.setVisibility(false);
     this.view.flxStoreDetails.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxStoreDetails.animate(animationDefObject, animationConfig);
    //  this.view.imgDown.animate(animationDefObject, animationConfig);
    //this.view.flxMenu.animate(animationDefObject, animationConfig);
    //frmCart.flxSearch.animate(animationDefObject, animationConfig);

    //this.view.flxSearch.setVisibility(false);

  },
  showPinDetails:function(pin){
    if(pin.showCallout){
      pin.showCallout=false;
      this.view.MapStores.updatePin(pin);
    }else{
      pin.showCallout=true;
      this.view.MapStores.updatePin(pin);
    }
  }
});