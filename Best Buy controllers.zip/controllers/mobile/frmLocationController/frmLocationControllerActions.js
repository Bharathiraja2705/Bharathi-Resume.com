define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onRowClick defined for segMenuItem **/
    AS_Segment_bc8d26c7b2c04f4fa1eb6014d3d4999d: function AS_Segment_bc8d26c7b2c04f4fa1eb6014d3d4999d(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.onMenu.call(this, rowNumber);
    }
});