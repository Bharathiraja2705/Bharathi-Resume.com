var cartName=[];
var cartAmount=[];
var cartArray=[];
var ProductName;
var cartItemLength=0;
var Price;
var array=[];
var catID;
var picID;
var productImage;
define({
onNavigate :function(detail){
  kony.model.ApplicationContext.showLoadingScreen("Loading");
  this.view.flxMenu.setVisibility(false);
//alert("sucess");
  var responseData=[
      {
        "menu":"Home",
        "logo":"appmenuhome.png"
      },
      {
        "menu":"Stores",
        "logo":"appmenustore.png"
      },
      {
        "menu":"Cart",
        "logo":"appmenucart.png"
      }
    ];
    this.view.segMenuItem.widgetDataMap={
      "lblMenu":"menu",
      "imgLogo":"logo"
    };
    //this.view.Head.imgBack.setVisibility(false);
    this.view.segMenuItem.setData(responseData);
  this.view.btnAddCart.onClick=this.addCart;
this.fetchProduct(detail);
  //this.view.flxReview.setVisibility(false);
  this.view.imgUp.src="uparrow.png";
  this.view.imgDown.src="downarrow.png";
   // this.view.imgUp.onTouchEnd=this.setAnimationReviewUp;
  this.view.imgUp.onTouchStart=this.setAnimationReviewUp;
   // this.view.imgDown.onTouchEnd=this.setAnimationReviewDown;
    this.view.Head.imgBack.onTouchEnd=this.goHome;
  this.view.Head.imgMenu.onTouchEnd=this.onVisibleMenu;

  
  
// this.service(detail);
},
  onMenu:function(rowNumber)
  { 
    if(rowNumber===0)
    {
      // this.setAnimationMenuClose;
      var nav = new kony.mvc.Navigation("frmHome");
      nav.navigate();
    }
    else if(rowNumber===1)
    {
//       this.setAnimationMenuClose;
//       alert("Comming Soon");
      var navi = new kony.mvc.Navigation("frmLocation");
      navi.navigate();
    }
    else if(rowNumber===2)
    {
      // this.setAnimationMenuClose;
      var navig = new kony.mvc.Navigation("frmCart");
      navig.navigate();
    }
  },
  onVisibleMenu:function()
  {
     if(this.view.flxMenu.isVisible===true)
      {
        this.setAnimationMenuClose();
      }
    else
      {
        this.setAnimationMenu();
      }
  },
   setAnimationMenu : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "1%"
      },
      "100": {
        "top": "2dp",
        "left": "0%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
   
    this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
  },
  setAnimationMenuClose : function(){
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(0.1,1);
    var animationDef = {
      "0": {
        "top": "2dp",
        "left": "0%"
      },
      "100": {
        "top": "2dp",
        "left": "1%"
      }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
    // this.view.flxMenu.setVisibility(true);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxMenu.animate(animationDefObject, animationConfig);
    this.view.flxMenu.setVisibility(false);
    this.view.flxMain.forceLayout();
  },
  goHome:function()
  {
    var navig=new kony.mvc.Navigation("frmProductDetails");
    navig.navigate(navSecond);
  },
fetchProduct : function(detail){
this.view.imgProduct.src=detail[4];
  productImage=detail[4];
  ProductName=detail[0];
  Price=detail[1];
  image=detail[1];
  catID=detail[0];
  picID=detail[1];
  var imgdata=[ProductName,Price];
  array.push(imgdata);
this.view.lblProductName.text=detail[2];
this.view.lblAmount.text="$"+detail[3];
  this.view.lblDescription.text=detail[5];
  this.view.lblRating.text="User Rating:"+detail[6];
if(detail[6]<1)
this.view.imgReview.src="ratings_star_1.png";
if((detail[6]>=1)&&(detail[5]<2))
this.view.imgReview.src="ratings_star_2.png";
if((detail[6]>=2)&&(detail[5]<3))
this.view.imgReview.src="ratings_star_3.png";
if((detail[6]>=3)&&(detail[5]<4))
this.view.imgReview.src="ratings_star_4.png";
if((detail[6]>=4)&&(detail[5]<5))
this.view.imgReview.src="ratings_star_5.png";
this.view.lblTotal.text=
"Total Number of Reviews: "+detail[7];
// },



// service: function(detail){
var serviceName = "BestBuy";
var integrationService = KNYMobileFabric.getIntegrationService(serviceName);
var operationName = "getData";
var params = {
"skuId":detail[1]



};
var headers={};
integrationService.invokeOperation(operationName, headers, params, this.operationSuccess, this.operationFailure);
},
operationSuccess: function(res){
var data =[];
data = res;
this.view.segReview.widgetDataMap=this.getWidgetData(data);
this.view.segReview.setData(data.reviews);
  
kony.model.ApplicationContext.dismissLoadingScreen();
// selectedValue=response[3];
//rating=rating+":"+selectedValue;
// this.view.lblAverageRating.text=rating;
},
operationFailure:function(res){
alert("failure");
},
getWidgetData:function(){
var response={
"lblGreat":"name",
"lblSubmit":"title",
//"imgRatings":"rating",
"lblReview":"comment"
};
return response;
},
addCart:function(){
// selectedProduct=ProductName;
// selectedProductPrice=detail[2];
  //cartDetails.push(ProductName,Price);
//   cartName.push(ProductName);
//   cartAmount.push(Price);
  //cartDetail.push((ProductName),(Price));
  //alert(cartDetail[0]);
  var data=[ProductName,Price];
  cartArray.push(data);
  cartItemLength++;
 // alert("The selected row items are "+ProductName+Price);
  //cartDetail=[ProductName,Price];
 // alert(data);
  //alert(cartName+cartAmount);
  alert("Added successfully");
//this.navigateToProductDetails();
//var row_items=this.view.segProduct.selectedRowItems;

},
  navigateToProductPicture:function()
  {
   var navigateTheDetails=new kony.mvc.Navigation("frmProductPicture");
  //cartDetail=[selectedProduct,selectedProductPrice];
navigateTheDetails.navigate(array);
    //alert(array);
  },
navigateToProductDetails:function(){
var navigateTheDetails=new kony.mvc.Navigation("frmCart");
  cartDetail=[selectedProduct,selectedProductPrice];
navigateTheDetails.navigate(detail);
},  
  
  setAnimationReviewUp : function(){
    //alert("Up Animation ");
    var transformObject1 = kony.ui.makeAffineTransform();
    //var transformObject2 = kony.ui.makeAffineTransform();
    //transformObject1.translate(10, 0);
    //transformObject2.translate(0, 0);


    transformObject1.scale(0.1,1);
    //transformObject2.scale(0,0);
    var animationDef = {
      "0": {
        "top": "100%",
        "left": "0%"
      },
      "100": {
        "top": "58%",
        "left": "0%"
      }
      // "100": {
      // "transform": transformObject1
      // }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
//     this.view.flxMenu.setVisibility(true);
      this.view.flxReview.setVisibility(true);
     this.view.imgDown.setVisibility(true);
      this.view.imgUp.setVisibility(false);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxReview.animate(animationDefObject, animationConfig);
      this.view.imgDown.animate(animationDefObject, animationConfig);
    //this.view.flxMenu.animate(animationDefObject, animationConfig);
    //frmCart.flxSearch.animate(animationDefObject, animationConfig);

    //this.view.flxSearch.setVisibility(false);

  },
  setAnimationReviewDown : function(){
  //  alert("Animation End");
    var transformObject1 = kony.ui.makeAffineTransform();
    //var transformObject2 = kony.ui.makeAffineTransform();
    //transformObject1.translate(10, 0);
    //transformObject2.translate(0, 0);


    transformObject1.scale(0.1,1);
    //transformObject2.scale(0,0);
    var animationDef = {
      "0": {
        "top": "70%",
        "left": "0%"
      },
      "100": {
        "top": "120%",
        "left": "0%"
      }
      // "100": {
      // "transform": transformObject1
      // }
    };
    //Create the animation configuration.
    animationConfig = {
      "duration": 0.9,
      "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    // Creates an object that defines an animation.
//     this.view.flxMenu.setVisibility(true);
     // this.view.flxReview.setVisibility(true);
    this.view.imgUp.setVisibility(true);
    this.view.imgDown.setVisibility(false);
    animationDefObject = kony.ui.createAnimation(animationDef);
    this.view.flxReview.animate(animationDefObject, animationConfig);
    this.view.flxReview.setVisibility(false);
    //this.view.flxMenu.animate(animationDefObject, animationConfig);
    //frmCart.flxSearch.animate(animationDefObject, animationConfig);

    //this.view.flxSearch.setVisibility(false);

  },
});