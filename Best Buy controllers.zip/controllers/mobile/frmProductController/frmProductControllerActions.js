define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for ButtonLink **/
    AS_Button_e1d0f139ac4645cb90fa92ff2f53b994: function AS_Button_e1d0f139ac4645cb90fa92ff2f53b994(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProductPicture");
        ntf.navigate();
    },
    /** onClick defined for btnAddCart **/
    AS_Button_i47faedd904046beaa28598f1097870c: function AS_Button_i47faedd904046beaa28598f1097870c(eventobject) {
        var self = this;
        return self.addCart.call(this);
    },
    /** onClick defined for HyperLinkButton **/
    AS_FlexContainer_adf613c0b94241649bb7a8c0c696206a: function AS_FlexContainer_adf613c0b94241649bb7a8c0c696206a(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProductPicture");
        ntf.navigate();
    },
    /** onTouchEnd defined for imgSerch **/
    AS_Image_c512ec95414c44ddb0cb7b3dd4d79d1c: function AS_Image_c512ec95414c44ddb0cb7b3dd4d79d1c(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmCart");
        ntf.navigate();
    },
    /** onTouchEnd defined for imgDown **/
    AS_Image_e4e38a02d70041fe943eb9bdb500bfa5: function AS_Image_e4e38a02d70041fe943eb9bdb500bfa5(eventobject, x, y) {
        var self = this;
        return self.setAnimationReviewDown.call(this);
    },
    /** onTouchEnd defined for imgUp **/
    AS_Image_f543b66e6f3c41beb0b9c0da78e2e5c5: function AS_Image_f543b66e6f3c41beb0b9c0da78e2e5c5(eventobject, x, y) {
        var self = this;
        return self.setAnimationReviewUp.call(this);
    },
    /** onRowClick defined for segMenuItem **/
    AS_Segment_db39124c839a4d67958c9abfdb4211c5: function AS_Segment_db39124c839a4d67958c9abfdb4211c5(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.onMenu.call(this, rowNumber);
    }
});