//productID="abcat0902001";
var detail;
var eventId;
define({

//     init:function()
//     {   
//       var responseData=[
//       {
//         "menu":"Home",
//         "logo":"appmenuhome.png"
//       },
//       {
//         "menu":"Stores",
//         "logo":"appmenustore.png"
//       },
//       {
//         "menu":"Cart",
//         "logo":"appmenucart.png"
//       }
//     ];
//     this.view.segMenuItem.widgetDataMap={
//       "lblMenu":"menu",
//       "imgLogo":"logo"
//     };
//     //this.view.Head.imgBack.setVisibility(false);
//     this.view.segMenuItem.setData(responseData);
//      // this.fetchProductByID(eventobject);
//       this.view.Head.imgBack.onTouchEnd=onBack;
//     },
  onBack:function()
  {
    var navigateToHome=new kony.mvc.Navigation("frmHome");
    navigateToHome.navigate();
  },
  fetchProductByID : function(event){
   //  this.view.lblPath.text="Results for : "+result;
    kony.model.ApplicationContext.showLoadingScreen("Loading");
   this.view.lblPath.text="Results for : "+result;
    var serviceName = "BestBuy";
    var integrationService = KNYMobileFabric.getIntegrationService(serviceName);
    var operationName = "getProducts";
    eventId=event.CatagoryById;
    var params = {
     "Product_ID":event.CatagoryById
      //"Product_ID":"abcat-205007"
      //"CATEGORY_ID":categoryID

    };
    var headers={};
    integrationService.invokeOperation(operationName, headers, params, this.operationSuccess, this.operationFailure);



  },
  // navigateToProduct:function(id)
  // {

  // },
  operationSuccess: function(res){
    var data =[];
    data = res;
    
    if(res.products.length>0){
      this.view.segProduct.widgetDataMap=this.getWidgetData(data);
      this.view.segProduct.setData(data.products);
      kony.model.ApplicationContext.dismissLoadingScreen();
      //this.productDetails();
      // this.view.lblPath.text=res.products.name;
    }
    else {
      alert("No Items");
      var nav=new kony.mvc.Navigation("frmHome");
      nav.navigate();
    }
    // {
    // // alert("sdfgh");
    // // this.navigateToProduct(categoryID);
    // var navigateToProduct = new kony.mvc.Navigation("frmDisplayProduct");
    // navigateToProduct.navigate(categoryID);

    // }
    // }
  },
  goBack:function()
  {
    alert("No Items");
  },
  operationFailure:function(res){
    alert("failure");
  },
  getWidgetData:function(){
    var response={
      "lblName":"name",
      "lblAmount":"salePrice",
      "imgProduct":"thumbnailImage",
      "lblRate":"customerReviewAverage",
     // "lblFree":"freeShipping"

    };
    // this.view.lblRating.text=Avg_User_Rating+lblRating;
    return response;
  },
 productDetails:function(){
productRatingCount=this.view.segProduct.selectedRowItems[0].customerReviewCount;
productRating=this.view.segProduct.selectedRowItems[0].customerReviewAverage;
selectedProductID=this.view.segProduct.selectedRowItems[0].sku;
selectedProduct=this.view.segProduct.selectedRowItems[0].name;
selectedProductPrice=this.view.segProduct.selectedRowItems[0].salePrice;
selectedProductImage=this.view.segProduct.selectedRowItems[0].mediumImage;
selectedProductDescription=this.view.segProduct.selectedRowItems[0].longDescription;
this.navigateToProductDetails();
var row_items=this.view.segProduct.selectedRowItems;
//alert("The selected row items are "+JSON.stringify(row_items));
},
navigateToProductDetails:function(){
var navigateTheDetails=new kony.mvc.Navigation("frmProduct");
detail=[eventId,selectedProductID,selectedProduct,selectedProductPrice,selectedProductImage,selectedProductDescription,productRating,productRatingCount];
navigateTheDetails.navigate(detail);
}
  // fetchsubCategories:function(){
  // selectedRowID=this.view.segDisplayProduct.selectedRowItems[0].id;
  // selectedRow=this.view.segDisplayProduct.selectedRowItems[0].name;
  // productID=selectedRowID;
  // this.fetchProductByID();
  // // path=path+"->"+selectedRow;
  // // this.view.lblHome.text=path;
  // }

});