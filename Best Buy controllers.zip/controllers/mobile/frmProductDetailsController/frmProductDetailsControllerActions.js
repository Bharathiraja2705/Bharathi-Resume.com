define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onNavigate defined for frmProductDetails **/
    onNavigate: function AS_Form_ib6e21e39efd495eaa2bfed6ce7950f5(eventobject) {
        var self = this;
        return self.fetchProductByID.call(this, eventobject);
    },
    /** onTouchEnd defined for imgBack **/
    AS_Image_cc3a572a43244795997bdf5a8da47457: function AS_Image_cc3a572a43244795997bdf5a8da47457(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    },
    /** onRowClick defined for segProduct **/
    AS_Segment_d4e036e87471469283fff72739ea53dd: function AS_Segment_d4e036e87471469283fff72739ea53dd(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.productDetails.call(this);
    },
    /** onRowClick defined for segMenuItem **/
    AS_Segment_ef26f487a209462499c615c13eb93049: function AS_Segment_ef26f487a209462499c615c13eb93049(eventobject, sectionNumber, rowNumber) {
        var self = this;
        return self.productDetails.call(this);
    }
});