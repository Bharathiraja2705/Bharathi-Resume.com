var finalData=[];
define({
onNavigate: function(array){
//this.view.WOContract.imgHumBurger.onClick=this.move;
this.invokeService(array);
  this.view.Head.imgBack.onTouchEnd=this.navigateToProductPage;
this.view.lbxPicture.onSelection=this.imageView;
  

},
  navigateToProductPage:function()
  {
    var nav=new kony.mvc.Navigation("frmProduct");
    nav.navigate(detail);
  },
invokeService : function(array){
var scope =this;
 // alert(array);
var integrationSvc = kony.sdk.getCurrentInstance().getIntegrationService("BestBuy");
var data={
  "Product_ID":catID,
 // "Product_ID":img[0],
};
var header={};
integrationSvc.invokeOperation("getProducts", header, data,operationSuccess,operationFailure);
function operationSuccess (res){
// var scope=this;
response=res.products;
var labelKey=1;
for(var item in response){
scope.view.imgPicture.src=response[item]["largeImage"];
//array[1]
if(response[item]["sku"]===picID)
{
for(var types in response[item]["images"]){
var info=[{
"id" : labelKey,
"listItems" : response[item]["images"][types].rel,
"productImage": response[item]["images"][types].href
}];
labelKey++;
finalData.push(info);

}
}
}
var result=[];
for(var iter in finalData){
result.push([finalData[iter][0].id,finalData[iter][0].listItems]);
}
scope.view.lbxPicture.masterData=result;
}
function operationFailure(res){
alert("failure");
}
},
imageView: function(){
var val=this.view.lbxPicture.selectedKeyValue[1];
// alert(val);
for(var key in finalData){
if(val===finalData[key][0].listItems){
this.view.imgPicture.src=finalData[key][0].productImage;
}
}
}
// fetchProductImage:function(sample){
// this.view.imgProductView.src=sample.image;
//}
});