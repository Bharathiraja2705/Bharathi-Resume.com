define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSearch **/
    AS_Button_ab7f5d2218c348bea94da29ba87cedc5: function AS_Button_ab7f5d2218c348bea94da29ba87cedc5(eventobject) {
        var self = this;
        var option = this.view.lbxPicture.selectedKeyValue[lb1];
        if (option == "lb1") {
            this.view.imgPicture.src = "tbBack.jpg";
        }
    },
    /** onNavigate defined for frmProductPicture **/
    onNavigate: function AS_Form_h310c1c403334081bfd0bbbe7cab77d8(eventobject) {
        var self = this;
    },
    /** onTouchEnd defined for imgBack **/
    AS_Image_bbad8865cf7c47dc928b39a0871c16e1: function AS_Image_bbad8865cf7c47dc928b39a0871c16e1(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProduct");
        ntf.navigate(detail);
    },
    /** onSelection defined for lbxPicture **/
    AS_ListBox_j2d9d1247fe64ef099d1d6b2bc74349d: function AS_ListBox_j2d9d1247fe64ef099d1d6b2bc74349d(eventobject) {
        var self = this;
    },
    /** onRowClick defined for segMenuItem **/
    AS_Segment_accabe60ad784e139a5280be132542a9: function AS_Segment_accabe60ad784e139a5280be132542a9(eventobject, sectionNumber, rowNumber) {
        var self = this;
    }
});